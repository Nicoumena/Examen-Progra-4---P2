﻿using System.Text.Json.Serialization;

namespace ExamenPokeApi.Models
{
    public class PokemonModel
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("status")]
        public string Status { get; set; }  

        [JsonPropertyName("species")]
        public string Species { get; set; } 

        [JsonPropertyName("image")]
        public string Image { get; set; }  
    }
}