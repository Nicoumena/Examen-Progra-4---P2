using ExamenPokeApi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text.Json; 

namespace ExamenPokeApi.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            PokemonModel personaje = new PokemonModel();

            using (var client = new HttpClient())
            {
                
                string url = "https://rickandmortyapi.com/api/character/1";

                client.DefaultRequestHeaders.Clear();

                var response = await client.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    var respuestaapi = await response.Content.ReadAsStringAsync();

                    
                    personaje = JsonSerializer.Deserialize<PokemonModel>(respuestaapi, new JsonSerializerOptions()
                    {
                        PropertyNameCaseInsensitive = true
                    });
                }
            }

            return View(personaje);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}